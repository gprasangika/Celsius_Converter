function converter()
{
    var cel = document.getElementById("Celcius").value;
    var far = ((cel - 32)*5)/9;
    document.getElementById("result").innerHTML = far ;
    document.getElementById("result").style.textAlign = "center"
    document.getElementById("result").style.paddingTop = "25px"
    document.getElementById("result").style.width = "200px"
    document.getElementById("result").style.height = "50px"
    document.getElementById("result").style.border = "2px solid #000000"
}
